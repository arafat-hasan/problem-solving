/***********************************************************************
*   FILE NAME: Normal-BFS.cpp
*
*   PURPOSE:
*
*   @author: Md. Arafat Hasan Jenin
*   EMAIL:  OpenDoor.Arafat@gmail.com
*
*   DEVELOPMENT HISTORY:
*       Date        Change          Version     Description
* -------------------------------------------------------------------
*    17 Jan 2017    New             1.0         Completed, Accepted
***********************************************************************/


#include <iostream>
#include <vector>
#include <list>
#include <queue>

using namespace std;
int cost[110];

int BFS(int s){
    queue<int> Q;
    Q.push(s);
    while(!Q.empty()) {
        int cn = Q.front();
        Q.pop();
        int sz = v[cn].size();
        for(i=0; i<sz; i++) {
            int adjn = v[cn][i];
            if(cost[cn]+1<cost[adjn]) {
                Q.push(adjn);
                cost[adjn]= cost[cn]+1;
            }
        }
    }
    return 0;
}

int main() {

    while(it1!=a.end()){
        list<int> it2=*it1;
        list<int>::iterator iter=it2.begin();
        while(iter!=it2.end()){
            cout<<*iter<<" ";
            iter++;
        }
        cout<<endl;
        it1++;
    }
    cout<<BFS(0);
    return 0;
}
