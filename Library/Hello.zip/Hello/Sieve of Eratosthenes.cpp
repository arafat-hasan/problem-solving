#include <stdio.h>
#include <math.h>
int prime[100];
void sieve(void);
int main()
{
	int i;
	sieve();
    for(i=0; i<100; i++)
        if(prime[i]==0)
            printf("%d ",i);
            
    return 0;
}

void sieve(void){
	
	int i,j, n=100;
    double root=sqrt(n);
    
	prime[0]=prime[1]=1;
	
	for(i=2;i<n;i+=2)
		prime[i]=1;
	
    for(i=3; i<=root; i+=2){
        if(!prime[i])
			for(j=i+i; j<n; j+=i)
				prime[j]=1;
    }
}
