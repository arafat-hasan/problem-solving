#include<bits/stdc++.h>
using namespace std;


///  ( 5 + ( 7 * 2 ) - 12 / 4 )

vector<string >v;

vector<string> parse(string str) {
    string tmp;
    stringstream ss;
    ss << str;
    while (ss >> tmp) {
        v.push_back(tmp);
    }
    return v;
}

int main() {

    string str;
    getline(cin, str);
    str = "( " + str + " )";

    cout << str << endl;
    vector<string> v = parse(str);

    for (int i = 0; i < (int)v.size() ; i++) {
        cout << v[i] << "\n";
    }

    stack<string> Stk;
    vector<string> P;

    /// 5 + ( 7 * 2 ) - 12 / 4

    for (int i = 0 ; i < (int)v.size() ; i++) {
        string tmp = v[i];
        /// Case 1 : number
        if (tmp[0] >= '0' && tmp[0] <= '9' ) {
            P.push_back(tmp);
        }
        /// Operator
        else if (tmp == "+" || tmp == "-" || tmp == "*" || tmp == "/") {
            if (tmp == "+" || tmp == "-"   ) {
                while ( !Stk.empty() &&  ( Stk.top() == "+" || Stk.top() == "-"
                                           || Stk.top() == "*" || Stk.top() == "/" )  ) {
                    P.push_back(Stk.top() );
                    Stk.pop();
                }
            } else if (tmp == "*" || tmp == "/" ) {
                while ( !Stk.empty() &&  ( Stk.top() == "*" || Stk.top() == "/" )  ) {
                    P.push_back(Stk.top() );
                    Stk.pop();
                }
            }
            Stk.push(tmp);
        } else {
            /// Opening
            if (tmp == "(") Stk.push(tmp);
            else { /// )
                while (Stk.top() != "(") {
                    P.push_back(Stk.top() );
                    Stk.pop();
                }
                Stk.pop();
            }
        }

        /// Par
    }

    cout << "Postfix Expression is : \n";
    for (int i = 0; i < (int)P.size(); i++) {
        cout << P[i] << " ";
    }
    cout << endl;

    return 0;
}

