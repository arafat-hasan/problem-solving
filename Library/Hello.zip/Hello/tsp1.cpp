/*
 * FILE: tsp1.cpp
 *
 * @author: Arafat Hasan Jenin <arafathasanjenin[at]gmail[dot]com>
 *
 * LINK:
 *
 * DATE CREATED: 28-11-17 09:16:49 (+06)
 * LAST MODIFIED: 28-11-17 10:59:17 (+06)
 *
 * DESCRIPTION:
 *
 * DEVELOPMENT HISTORY:
 * Date         Version     Description
 * --------------------------------------------------------------------
 * 28-11-17     1.0         {{File Created}}
 *
 *
 *                 _/  _/_/_/_/  _/      _/  _/_/_/  _/      _/
 *                _/  _/        _/_/    _/    _/    _/_/    _/
 *               _/  _/_/_/    _/  _/  _/    _/    _/  _/  _/
 *        _/    _/  _/        _/    _/_/    _/    _/    _/_/
 *         _/_/    _/_/_/_/  _/      _/  _/_/_/  _/      _/
 */

///////////////////////////////////////////////////////////////////////

#include <iostream>
#include <climits>
#include <cmath>
#include <cstring>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <iomanip>
#include <utility>
#include <sstream>
#include <algorithm>
#include <stack>
#include <set>
#include <list>
#include <map>
#include <unordered_map>
#include <queue>
#include <deque>
#include <vector>
#include <stdint.h> //uint32_t
#include <functional>
#include <bitset>

using namespace std;

typedef long long           ll;
typedef double              lf;
typedef unsigned long long  ull;
typedef pair<int, int>      pii;
typedef vector<pii>         vpii;
typedef vector<int>         vi;

#define __FastIO        ios_base::sync_with_stdio(false); cin.tie(0)

#define forr(i, a, b)   for (__typeof (a) i=a; i<=b; i++)
#define rof(i, b, a)    for (__typeof (a) i=b; i>=a; i--)
#define rep(i, n)       for (__typeof (n) i=0; i<n; i++)
#define forit(i, s)     for (__typeof ((s).end ()) i = (s).begin (); i != (s).end (); ++i)
#define all(ar)         ar.begin(), ar.end()
#define fill(ar, val)   memset(ar, val, sizeof(ar))
#define clr(a)          memset(a, 0, sizeof(a))

#define nl              cout << '\n';
#define sp              cout << ' ';
#define ckk             cout << "##########\n"
#define pb              push_back
#define debug1(x)       cerr << #x << ": " << x << endl
#define debug2(x, y)    cerr << #x << ": " << x << '\t' << #y << ": " << y << endl
#define debug3(x, y, z) cerr << #x << ": " << x << '\t' << #y << ": " << y << '\t' << #z << ": " << z << endl

#define PI              acos(-1.0)
#define INF             0x7fffffff
#define MOD             1000000007
#define EPS             1e-7
#define MAX             10000005

////////////////////////// START HERE //////////////////////////

class TSP {
public:
    int dist[15][15];
    int dp[(1 << 12) + 5][12];

    int tsp(int n) {

        int p, ans;
        // Run Floyd–Warshall to remove Triangle-Inequality
        // It is not necessary for TSP
        //for (k = 0; k < n; k++) {
        //    for (i = 0; i < n; i++) {
        //        for (j = 0; j < n; j++) {
        //            if (i != j && i != k && j != k)
        //                dist[i][j] = min(dist[i][k] + dist[k][j], dist[i][j]);
        //        }
        //    }
        //}

        memset(dp, -1, sizeof(dp));
        dp[1][0] = 0;

        for (int i = 1; i < (1 << n); i++) {

            for (int j = 0; j < n; j++) {

                if (dp[i][j] == -1) continue;
                for (int k = 1; k < n; k++) {

                    if ((i & (1 << k)) != 0) continue; // check either kth bit of i is 0 : 1
                    p = (i | (1 << k)); // ON kth bit of i and store it p
                    if (dp[p][k] == -1) dp[p][k] = dp[i][j] + dist[j][k];
                    dp[p][k] = min(dp[p][k], dp[i][j] + dist[j][k]);
                }
            }
        }

        ans = INF;
        for (int i = 1; i < n; i++) {

            if (dp[(1 << n) - 1][i] > 0) ans = min(ans, dp[(1 << n) - 1][i] + dist[i][0]);
        }
        return ans;
    }
};

int main() {

    __FastIO;
    int n, ans;
    TSP tsp;

    while (cin >> n) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                cin >> tsp.dist[i][j];
            }
        }
        ans = tsp.tsp(n);
        cout << ans << endl;
    }

    return 0;
}


// Input
// 4
// 0 4 1 2
// 4 0 7 5
// 1 7 0 3
// 2 5 3 0
// 4
// 0 10 14 20
// 5 0 9 10
// 6 13 0 12
// 2 8 9 0

// Output
// 13
// 33
