/***************************************************************
*   FILE NAME:  BFS.cpp
*
*   PURPOSE:
*
*   @author: Md. Arafat Hasan Jenin
*   EMAIL:
*
*   DEVELOPMENT HISTORY:
*       Date        Change      Version     Description
* ---------------------------------------------------------------
*   23 Jan 16      New         1.0         Completed
*****************************************************************/

#include <iostream>
#include <vector>
#include <cstdio>
#include <queue>
#include <limits.h>
using namespace std;

vector<int> adj [100];
int visited [100], cost[100];

void bfs_vis(int s, int n) {

    int u, v, i, m;
    for(i=0; i < n; i++) {
        visited[i] = 0;
        cost[i] = -1;
    }

    queue<int> Q;
    Q.push(s);
    visited[s] = 1;
    cost[s] = 0;

    while(!Q.empty()) {
        u = Q.front();
        Q.pop();
        m = adj[u].size();
        for(i = 0; i < m; i++) {
            if(visited[adj[u][i]] == 0) {
                v = adj[u][i];
                visited[v] = 1;
                Q.push(v);
                cost[v] = cost[u]+1;
            }
        }
    }
}




int BFS(int s, int n) {
    int i, cn, v, sz;
    for(i = 0; i < n; i++)
        cost[i]=INT_MAX;

    queue<int> Q;
    Q.push(s);
    cost[s]=0;
    while(!Q.empty()) {
        cn = Q.front();
        Q.pop();
        sz = adj[cn].size();
        printf("#%i ", cn);
        for(i=0; i<sz; i++) {
            v = adj[cn][i];
            if(cost[cn]+1<cost[v]) {
                Q.push(v);
                cost[v]= cost[cn]+1;
            }
        }
    }
    return 0;
}

int main() {

    int a, b, s, n, edge, i, j;
    cout << "#######" << endl;
    cin >> s >> n >> edge;
    for(i=0; i < edge; i++) {
        cin >> a >> b;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }

    for(i = 0; i <= n; i++) {
        printf("%i ",i);
        edge = adj[i].size();
        for(j=0; j< edge; j++)
            printf("%i ",adj[i][j]);
        printf("\n");
    }
    cout << endl;
    BFS(s, n);
    cout << endl;

    for(i = 0; i <= n; i++) {
        printf("%i %i\n",i, cost[i]);
    }


    cout << endl;

    return  0;
}

