#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#define g1 (1+sqrt(5))/2
#define g2 (1-sqrt(5))/2
long double fibo(long double f){
	return (pow(g1,f)-pow(g2,f))/sqrt(5);
}
int main(){
long double n;
	scanf("%Lf",&n);
	printf("%.0Lf\n",fibo(n-1));
	return 0;
}
