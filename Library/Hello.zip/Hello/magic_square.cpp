/*
 * FILE: /media/Softwares/Programming/Finalized/magic_square.cpp
 *
 * @author: Arafat Hasan Jenin <arafathasanjenin[at]gmail[dot]com>
 *
 * LINK:
 *
 * DATE CREATED: 01-11-17 00:56:35 (+06)
 * LAST MODIFIED: __last_modified
 *
 * DESCRIPTION:
 *
 * DEVELOPMENT HISTORY:
 * Date         Version     Description
 * --------------------------------------------------------------------
 * 01-11-17     1.0         {{File Created}}
 *
 *
 *                 ██╗███████╗███╗   ██╗██╗███╗   ██╗
 *                 ██║██╔════╝████╗  ██║██║████╗  ██║
 *                 ██║█████╗  ██╔██╗ ██║██║██╔██╗ ██║
 *            ██   ██║██╔══╝  ██║╚██╗██║██║██║╚██╗██║
 *            ╚█████╔╝███████╗██║ ╚████║██║██║ ╚████║
 *             ╚════╝ ╚══════╝╚═╝  ╚═══╝╚═╝╚═╝  ╚═══╝
 */

///////////////////////////////////////////////////////////////////////

#include <iostream>
#include <climits>
#include <cmath>
#include <cstring>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <iomanip>
#include <utility>
#include <sstream>
#include <algorithm>
#include <stack>
#include <set>
#include <list>
#include <map>
#include <unordered_map>
#include <queue>
#include <deque>
#include <vector>
#include <stdint.h> //uint32_t
#include <functional>
#include <bitset>

using namespace std;

typedef long long           ll;
typedef double              lf;
typedef unsigned long long  ull;
typedef pair<int, int>      pii;
typedef vector<pii>         vpii;
typedef vector<int>         vi;

#define __FastIO        ios_base::sync_with_stdio(false); cin.tie(0)

#define forr(i, a, b)   for (__typeof (a) i=a; i<=b; i++)
#define rof(i, b, a)    for (__typeof (a) i=b; i>=a; i--)
#define rep(i, n)       for (__typeof (n) i=0; i<n; i++)
#define forit(i, s)     for (__typeof ((s).end ()) i = (s).begin (); i != (s).end (); ++i)
#define all(ar)         ar.begin(), ar.end()
#define fill(ar, val)   memset(ar, val, sizeof(ar))
#define clr(a)          memset(a, 0, sizeof(a))

#define nl              cout << '\n';
#define sp              cout << ' ';
#define ckk             cout << "##########\n"
#define pb              push_back
#define debug1(x)       cerr << #x << ": " << x << endl
#define debug2(x, y)    cerr << #x << ": " << x << '\t' << #y << ": " << y << endl
#define debug3(x, y, z) cerr << #x << ": " << x << '\t' << #y << ": " << y << '\t' << #z << ": " << z << endl

#define PI              acos(-1.0)
#define INF             0x7fffffff
#define MOD             1000000007
#define EPS             1e-7
#define MAX             10000005

////////////////////////// START HERE //////////////////////////

class Magic_Square {
public:
    int mat[1000][1000];

    void print(int n) {
        int rowsum, corner = 0;
        vi v(n);
        rep(i, n) corner += mat[i][i];
        cout << "\nCalculated magic number is: " << (n * n * n + n) / 2 << endl;
        cout << "Magic square of order " << n << ":\n\n";
        rep(i, n) {
            rowsum = 0;
            rep(j, n) {
                cout << mat[i][j] << '\t';
                rowsum += mat[i][j];
                v[i] += mat[i][j];
            }
            cout << "|" << rowsum << endl;
        }

        rep(i, n) cout << "________";
        cout << "|_____" << endl;
        rep(i, n) cout << v[i] << '\t';
        cout << "|" << corner;
        cout << endl << endl;
    }

    void magic_single(int n) {
        cout << "I have found no pattern for order " << n << " :-(\n";
    }

    void magic_double(int n) {
        int mn = n / 4;
        for (int i = 0, revY = n - 1; i < n; i++, revY--) {
            for (int j = 0, revX = n - 1; j < n; j++, revX--) {
                if (j < mn or j >= (n - mn)) {
                    if (i < mn or i >= (n - mn)) mat[i][j] = (i * n) +  (j + 1);
                    else mat[i][j] = (revY * n) + (revX + 1);
                } else {
                    if (i >= mn and i < (n - mn)) mat[i][j] = (i * n) +  (j + 1);
                    else mat[i][j] = (revY * n) + (revX + 1);
                }
                //debug3(i, j, mat[i][j]);
            }
        }
    }

    void magic_odd(int n) {
        int blocks = (n * n), preX = n / 2, preY = 0;
        for (int i = 1, x = n / 2, y = 0; i <= blocks; i++, x++, y--) {
            if (x == n and y == -1) x--, y += 2;
            else if (x == n) x = 0;
            else if (y == -1 ) y = n - 1;
            if (mat[y][x]) x = preX, y = preY + 1;
            mat[y][x] = i;
            preX = x, preY = y;
            //debug3(x, y, mat[y][x]);
        }

    }
};

int main() {
    //__FastIO;
    int size;
    Magic_Square obj;
    while (cin >> size) {
        memset(obj.mat, 0, sizeof(obj.mat));
        if (size < 3) {
            cout << "Magic square of order " << size << " is not possible\n\n";
        } else if (size & 1) { // Odd
            obj.magic_odd(size);
        } else if (size % 4 == 0) { // Doubly even
            obj.magic_double(size);
        } else { // Single even
            obj.magic_single(size);
        }

        if (size >= 3)
            obj.print(size);
    }
    return 0;
}

